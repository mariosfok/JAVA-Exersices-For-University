import java.util.ArrayList;

public class Suspect {

	
	private String name;
	private String codedName;
	private String city;
	
	private ArrayList<String> phoneNumbers;
	private ArrayList<Suspect> possibleAssociates;
	

	
	public Suspect(String name, String codedName, String city) {
		this.name = name;
		this.codedName = codedName;
		this.city = city;
		this.phoneNumbers = new ArrayList<>();
		this.possibleAssociates = new ArrayList<>();
		
	}
	
	public void addNumber(String number) {
		phoneNumbers.add(number);
	}
	
	
	
	public void addAssociate(Suspect associate) {
	       if (!this.possibleAssociates.contains(associate)) {
	           this.possibleAssociates.add(associate);	            
	        } 	
          }
	


	public ArrayList<Suspect> getPossibleAssociates() {
		return possibleAssociates;
	}

	public void setPossibleAssociates(ArrayList<Suspect> possibleAssociates) {
		this.possibleAssociates = possibleAssociates;
	}

	public boolean isConnectedTo(Suspect aSuspect) {
			if (this.possibleAssociates.contains(aSuspect))return true;					
			else return false;
	}
	
	public ArrayList<Suspect> getCommonPartners(Suspect aSuspect) {
	    ArrayList<Suspect> commonPartners = new ArrayList<>();  
	    
	    for (Suspect partner : this.possibleAssociates) {
	      
	        if (aSuspect.possibleAssociates.contains(partner)) {
	            commonPartners.add(partner); 
	        }
	    }
	    
	    return commonPartners;
	}

	public String getName() {
		return name;
	}
	
	public String getCodeName() {
		return codedName;
	}
	
	public ArrayList<String> getPhoneNumbers() {
		return phoneNumbers;
	}
	
	public String getCity() {
		return city;
	}

	
		
}