
public class PhoneCall extends Communication {
	
	private int callTime;
	
	
public PhoneCall(String num1, String num2, int day, int month, int year,int callTime) {
	super(num1, num2, day, month, year);
	this.callTime = callTime;
	}

public int  getCallTime() {
	return callTime;
}



public void printInfo() {
		System.out.println("This phone call has the followeing info");
		System.out.println("Between "+num1+" --- "+num2);
		System.out.println("on "+year+"/"+month+"/"+day);
		System.out.println("Duration: "+callTime);
	}
}
