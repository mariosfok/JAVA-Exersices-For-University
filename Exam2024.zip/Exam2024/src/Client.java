
public class Client {
	
	protected String name;
	protected double xm; //xiliometra minaios
	
	
	public Client(String name, double xm) {
		this.name = name;
		this.xm = xm;
	}
	
	public double calculateMonthlyCharge(double timiAnaXiliometro) {
		return this.xm * timiAnaXiliometro;
	}

	public String getName() {
		return name;
	}

	public double getXm() {
		return xm;
	}

}
