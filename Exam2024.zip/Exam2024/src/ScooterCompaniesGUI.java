import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ScooterCompaniesGUI extends JFrame {
	
	private JPanel panel = new JPanel();
	private JList<String> companiesList = new JList<>();
	private DefaultListModel<String> companyModel = new DefaultListModel<>();
	
	private JButton clientsButton = new JButton("Find Number of Clients");
	
	private JTextField clientsTextField = new JTextField("number of clients");
	
	private ArrayList<ScooterCompany> companies;
	
	public ScooterCompaniesGUI(ArrayList<ScooterCompany> companies,ArrayList<String[]> prices) {
		
		this.companies = companies;
		
//		companyModel.addElement("Company 1");
//		companyModel.addElement("Company 2");
//		companyModel.addElement("Company 3");
		
		for(ScooterCompany company : companies) {
			companyModel.addElement(company.getName());
		}
		companiesList.setModel(companyModel);
		
		clientsButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				String companyName = companiesList.getSelectedValue();
				ScooterCompany selectedCompany = null;
				
				for(ScooterCompany company : companies) {
					if(company.getName().equals(companyName)) {
						selectedCompany = company;
						break;
					}
				}
				
				clientsTextField.setText(companyName+" "+selectedCompany.calculateTotalCharge(prices, companyName));
				
			
				
				
				
			}
			
		});
		
		
		
		
			
		panel.add(companiesList);
		panel.add(clientsButton);
		panel.add(clientsTextField);
		
		this.setContentPane(panel);
		
		this.setVisible(true);
		this.setSize(400, 400);
		this.setTitle("Clients per Company");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
}
