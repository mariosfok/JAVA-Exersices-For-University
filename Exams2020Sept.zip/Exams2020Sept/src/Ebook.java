
public class Ebook extends BookInGeneral{

	
	public Ebook(String name, String author, int code, double mb) {
		super(name, author, code);
        this.mb = mb;
}




	private double mb;
	
	
	
	
	@Override
	public String toString() {
		return ("Book: "+title+", "+author+", "+"("+code+")"+", "+mb);
		
	}

}
