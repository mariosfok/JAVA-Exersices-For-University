import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GUI extends JFrame {
    private JFrame frame = new JFrame();
    private JTextField textField = new JTextField();
    private JButton button1 = new JButton("Εμφάνιση Αυτονομίας");
    private JButton button2 = new JButton("Αποθήκευση σε Αρχείο");
    private Fleet selectedFleet;
    private JPanel panel = new JPanel();

    public GUI(ArrayList<Fleet> fleets) {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String locationName = textField.getText();
                selectedFleet = null;

                for (Fleet fleet : fleets) {
                    if (locationName.equals(fleet.getName())) {
                        selectedFleet = fleet;
                        break;
                    }
                }

                if (selectedFleet == null) {
                    textField.setText("Η τοποθεσία δεν βρέθηκε.");
                    return;
                }

                textField.setText(locationName + ": " + selectedFleet.getTaxis().size() + " Ταξί, Αυτονομία: " + selectedFleet.calculateAutonomia());
            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String locationName = textField.getText();
                selectedFleet = null;

                for (Fleet fleet : fleets) {
                    if (locationName.equals(fleet.getName())) {
                        selectedFleet = fleet;
                        break;
                    }
                }

                if (selectedFleet == null) {
                    textField.setText("Η τοποθεσία δεν βρέθηκε.");
                    return;
                }

                File file = new File("ICS24038.txt");
               
                	 
					try {
					
						BufferedWriter writer = new BufferedWriter(new FileWriter(file));
						
						writer.write(locationName);
	                    writer.newLine();

	                    for (Taxi taxi : selectedFleet.getTaxis()) {
	                        writer.write(taxi.toString());
	                        writer.newLine();
	                    }

	                    writer.write("Συνολική Αυτονομία: " + selectedFleet.calculateAutonomia());
	                    
	                writer.close();
						
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                	
                	
                	
                	
       
                	
            }
        });

        textField.setPreferredSize(new Dimension(250, 30));
        panel.add(button1);
        panel.add(button2);
        panel.add(textField);

        frame.add(panel);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setSize(500, 500);
    }
}
