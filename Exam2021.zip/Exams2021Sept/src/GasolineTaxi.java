
public class GasolineTaxi extends Taxi{

	
	private int lt;
	private double mesiKat;
	
	
	public GasolineTaxi(String numKyk, String name, int lt, double mesiKat) {
		super(numKyk, name);
		this.lt = lt;
		this.mesiKat = mesiKat;
	}


	public int getLt() {
		return lt;
	}


	public double getMesiKat() {
		return mesiKat;
	}


	@Override
	public double calculate() {
		return 90 *((double)lt/mesiKat);
	}


	@Override
	public String toString() {
		return "NAI";
	}

}
