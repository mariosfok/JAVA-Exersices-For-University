import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		Fleet fleetHr = new Fleet("HRAKLEIO");
		Fleet fleetRe = new Fleet("RETHIMNO");
		
		GasolineTaxi gasTaxi1 = new GasolineTaxi("4324","MARIOS",200,60);
		GasolineTaxi gasTaxi2 = new GasolineTaxi("3123","SAM",300,60);
		
		ElectricalTaxi eleTaxi1 = new ElectricalTaxi("1231","MANOS",4);
		ElectricalTaxi eleTaxi2 = new ElectricalTaxi("6436","MAN",7);
		
		fleetHr.storeTaxis(gasTaxi1);
		fleetHr.storeTaxis(eleTaxi1);
		
		fleetRe.storeTaxis(gasTaxi2);
		fleetRe.storeTaxis(eleTaxi2);
		
		ArrayList<Fleet> fleets = new ArrayList<>();
		fleets.add(fleetRe);
		fleets.add(fleetHr);
		
		new GUI(fleets);
		
		
		
	}

}
