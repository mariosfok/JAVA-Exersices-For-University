import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		//---------Company and some clients-------------
		ScooterCompany orange = new ScooterCompany("Orange");
		Client client1 = new Client("Papadopoulos", 78);
		BusinessClient busClient1 = new BusinessClient("Nikolaou", 144, 10);
		
		//---------Company and some clients-------------
		ScooterCompany hopandride = new ScooterCompany("HopAndRide");
		Client client2 = new Client("Hliadis", 105);
		Client client3 = new Client("Andreou", 97);
		BusinessClient busClient2 = new BusinessClient("Georgiou", 220, 15);
		
		//---------Company and some clients-------------
		ScooterCompany citybikers = new ScooterCompany("CityBikers");
		Client client4 = new Client("Symeonidis", 56);
		BusinessClient busClient3 = new BusinessClient("Mitroudis", 84, 20);
		
		//---------ArrayList of Companies-------------
		ArrayList<ScooterCompany> companies = new ArrayList<>();
		companies.add(orange);
		companies.add(hopandride);
		companies.add(citybikers);
		
		//---------Adding clients to companies-------------
		orange.addClient(client1);
		orange.addClient(busClient1);
		hopandride.addClient(client2);
		hopandride.addClient(client3);
		hopandride.addClient(busClient2);
		citybikers.addClient(client4);
		citybikers.addClient(busClient3);
		
		
		
		//--------Calculate total Charge for each company-------------
				
		ArrayList<String[]> prices = Main.readFile("Prices.txt");
		
		for(ScooterCompany company : companies) {
			String companyName = company.getName();
			System.out.println(companyName+", Total Charge: "+company.calculateTotalCharge(prices,companyName));
	}
		
		
		ScooterCompaniesGUI frame = new ScooterCompaniesGUI(companies,prices);
	}
	
	public static ArrayList<String[]> readFile(String fileName) {
		
		ArrayList<String[]> results = new ArrayList<String[]>();

		try {
			FileReader fileIn = new FileReader(fileName);
			BufferedReader in = new BufferedReader(fileIn);
			
			String line;

			while( (line = in.readLine()) != null) {
				String[] parts = line.split(",");
				results.add(parts);
			}
		
			in.close();
			fileIn.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return results;		
	}


}
