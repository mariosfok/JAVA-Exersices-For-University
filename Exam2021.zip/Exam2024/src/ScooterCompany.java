import java.util.ArrayList;

public class ScooterCompany {

	private String name;
	private ArrayList<Client> clients;
	
	public ScooterCompany(String name) {
		this.name = name;
		this.clients = new ArrayList<>();
	}
	
	public void addClient(Client client) {
		this.clients.add(client);
	}
	
	public double calculateTotalCharge(ArrayList<String[]> prices,String companyName) {
		double sum = 0;
		
		for(Client client : this.clients) {
			for(String[] name : prices) {
				 if(name[0].equals(companyName))
					sum += client.calculateMonthlyCharge(Double.parseDouble(name[1]));
				}
			}
			
		
		return sum;
	}

	public String getName() {
		return name;
	}

	public ArrayList<Client> getClients() {
		return clients;
	}
	
	
}
