
public class BusinessClient extends Client{

	private int miniaioTelos;
	
	public BusinessClient(String name, double xm, int miniaioTelos) {
		super(name, xm);
		this.miniaioTelos = miniaioTelos;
	}
	
	public double calculateMonthlyCharge(double timiAnaXiliometro) {
		
		if(this.miniaioTelos == 10)
			return (this.xm * timiAnaXiliometro * 0.9) + miniaioTelos;
		else if (this.miniaioTelos == 15)
			return (this.xm * timiAnaXiliometro * 0.7) + miniaioTelos;
		else
			return (this.xm * timiAnaXiliometro * 0.5) + miniaioTelos;
	}

}
