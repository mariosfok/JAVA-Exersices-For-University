import java.util.ArrayList;
import java.util.List;

public class BookStore {

	
	private List<Book> books;
	
	
	public BookStore() {
		this.books = new ArrayList<>();
	}
	
	
	public void addElement(Book book) {
		books.add(book);
	}
	
	
	public void searchElement(int code) {
		for(Book book : books) {
		
			if(book.getCode() == code) {
				System.out.println("Το βιβλιο ειναι καταχωρημένο.");
				System.out.println("------------------------------");
				System.out.println(book);	
				
			}else
				System.out.println("Το βιβλιο δεν ειναι καταχωρημένο.");
			
		}
	}


	public List<Book> getBooks() {
		return books;
	}
	
	
}
