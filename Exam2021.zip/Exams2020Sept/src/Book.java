public class Book extends BookInGeneral {
	
	

	protected String title;
	protected String author;
	protected int code;
	private int pages;
	
	public Book(String name, String author, int code, int pages) {
		super(name, author, code);

		this.pages = pages;

	}


	
	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public int getCode() {
		return code;
	}

	public int getPages() {
		return pages;
	}

	@Override
	public String toString() {
		return ("Book: "+title+", "+author+", "+"("+code+")"+", "+pages);
		
	}



	

}
