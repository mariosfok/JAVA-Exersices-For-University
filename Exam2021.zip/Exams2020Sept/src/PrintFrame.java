import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

public class PrintFrame extends JFrame {
    private ArrayList<Book> books;
    private JButton button;
    private JTextArea textField;

    public PrintFrame(ArrayList<Book> books) {
        this.books = books;

        // Ταξινόμηση βιβλίων
        Collections.sort(books);

        // Γραφικό περιβάλλον
        button = new JButton("Εκτύπωση");
        textField = new JTextArea(20, 50);

        this.add(button);
        this.add(new JScrollPane(textField));
        this.setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        this.pack();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        // Λειτουργικότητα κουμπιού
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder output = new StringBuilder();
                int bookCount = 0;
                int eBookCount = 0;

                // Επεξεργασία και εκτύπωση
                for (Book book : books) {
                    output.append(book.toString()).append("\n");
                    if (book instanceof Ebook) {
                        eBookCount++;
                    } else {
                        bookCount++;
                    }
                }

                output.append("\nBook Count: ").append(bookCount)
                      .append("\nEbook Count: ").append(eBookCount);

                textField.setText(output.toString());
            }
        });
    }
}
