import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		Book book1 = new Book("LOTR","STEPHEN",293,637);
		Book book2 = new Book("STAR WARS","LUCAS",767,453);
		
		Ebook ebook1 = new Ebook("BREAKING BAD","FWKIANOS",321,541,25.7);
		Ebook ebook2 = new Ebook("ATTACK ON TITAN","IAPWNAS",411,201,17.6);
				
		
		BookStore store = new BookStore();
		
		store.addElement(book1);
		store.addElement(book2);
		
		store.addElement(ebook1);
		store.addElement(ebook2);
		
		store.searchElement(321); //UPARXEI
		store.searchElement(2); // DEN YPARXEI
		
		ArrayList<Book> books = (ArrayList<Book>) store.getBooks();
		
		new PrintFrame(books);
	}

}
