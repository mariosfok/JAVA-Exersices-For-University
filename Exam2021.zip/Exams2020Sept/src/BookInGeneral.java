
public  abstract class BookInGeneral implements Comparable<BookInGeneral>{
	
	protected String name;
	protected String author;
	protected int  code;
	
	public BookInGeneral(String name, String author, int code) {
		this.name= name;
		this.code = code;
		this.author = author;
	}
	
	public abstract String toString();

	@Override
	public int compareTo(BookInGeneral o) {
		// TODO Auto-generated method stub
		return  Integer.compare(this.code, o.code);
	}

	
	
	
}
