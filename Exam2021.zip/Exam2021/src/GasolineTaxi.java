
public class GasolineTaxi {

}
