
public class ElectricalTaxi {

}
