
public class Fleet {
	
	private String name;
	
	
	public Fleet() {
		
		this.name = name;
	
	}

}
