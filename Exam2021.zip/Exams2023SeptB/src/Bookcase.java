
public class Bookcase extends Furniture{
	
	private int numRaf;
	
	public Bookcase(String model, int weight, int category, int numRaf) {
		super(model, weight, category);
		this.numRaf = numRaf;
	
	}

	@Override
	public double calculateCost() {
		if(this.category == 1) {
			return (50*numRaf) + (50*numRaf)*(20/100);
		}
		else if(this.category == 2) {
			return (50*numRaf) + (50*numRaf)*(30/100);
		}else {
			return (50*numRaf) + (50*numRaf)*(50/100);
		}
	}

	@Override
	public String toString() {
		
		String categoryTemp = "";
		if(this.category ==1)
			categoryTemp = "Plastic";
		else if (this.category ==2)
			categoryTemp = "Metallic";
		else
			categoryTemp = "Wooden";
		
		
		
		return "- Bookcase info: \n"
	    +model+", "+this.calculateCost()+"Euro"+
	    "\nCategory: "+categoryTemp+
		"\nWeight: "+this.weight+
		"\nShelves: "+this.numRaf;
	}
	
	

}
