
public abstract class Furniture {

	
	

	protected String model;
	protected int weight;
	protected int category;
	
	
	public Furniture(String model, int weight, int category) {
		this.model = model;
		this.weight = weight;
		this.category = category;
		
	}
	
	public abstract double calculateCost();
	
	public abstract String toString();
	
	
	
	public String getModel() {
		return model;
	}


	public int getWeight() {
		return weight;
	}


	public int getCategory() {
		return category;
	}

}
