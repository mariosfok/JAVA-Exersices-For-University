import java.util.Scanner;

public class GameTime {
	private Details playerDetails;
	
    private TableΜaker tableMaker;
    private char[][] table;
    private char chip1;
    private char chip2;
    private boolean isFirstPlayerTurn;
    private Scanner obj;
    private int col;
    private int row;
    private String currentPlayer;
    
    public GameTime(Details playerDetails, TableΜaker tableMaker, char[][] table) {
        this.playerDetails = playerDetails; 
        this.tableMaker = tableMaker; 
        this.table = table;
        this.obj = new Scanner(System.in);//Αρχικοποιηση του scanner ωστε να ειναι προσβασιμος για ολες τις μεθοδους της κλασης.
        this.isFirstPlayerTurn = playerDetails.getStartingPlayer().equals(playerDetails.getName1());
        this.col = tableMaker.getCol(); 
        this.row = tableMaker.getRow();
        this.chip1 = playerDetails.getStartingPlayerChip();
        this.chip2 = playerDetails.getOtherPlayerChip();
        this.currentPlayer = playerDetails.getStartingPlayer();
    }
    
    
    
    public void Gameplay() {
    	Scanner obj = new Scanner(System.in);
    	boolean gameWon = false;
    	boolean boardFull = false;
    	
    	while(!gameWon && !boardFull) {
    		
    		int selectColumn = getPlayerMove();
    		
    		char currentChip = isFirstPlayerTurn ? chip1 : chip2; //chip1 = starting player, chip2= other player
    		  placeChip(currentChip, selectColumn);
    		  tableMaker.printCurrentTable();
              gameWon = checkWinner(currentChip);
              boardFull = isBoardFull();
  
              if (gameWon) {
            	  System.out.println("The winner is: "+ currentPlayer);
            	  break;}
              
              if (boardFull)
            	  System.out.println("The game has ended");
              
              
 
              //Εναλλαγη παικτων.
              isFirstPlayerTurn = !isFirstPlayerTurn;
              
              if (currentPlayer == playerDetails.getStartingPlayer())
				currentPlayer = playerDetails.getName2();
			else
				currentPlayer = playerDetails.getStartingPlayer();
    		
    	}
    	obj.close();
    }
    
    private int getPlayerMove() {
        int selectColumn = -1; 
        
        do{
            System.out.print((isFirstPlayerTurn ? playerDetails.getName1() : playerDetails.getName2()) + ", your turn. Select column: ");
            selectColumn = obj.nextInt();

            
            if (selectColumn < 1 || selectColumn > col) 
            	System.out.println("Invalid column. Please choose a column between 1 and " + col);
            
        }while(selectColumn < 1 || selectColumn > col);

        return selectColumn - 1; // -1 ωστε να ειναι στα ορια 
    }
    


    
    public void placeChip(char Chip, int Col) {
        for (int i = row - 1; i >= 0; i--) {
            if (table[i][Col] == '-') { 
                table[i][Col] = Chip;
                break; 
            }
        }
    }

    
    
    
    public boolean checkWinner(char currentChip) {
    	//Ελεγχος για νικη, οριζοντια 
    	 for (int i = 0; i < row; i++) {	        
    	        for (int j = 0; j < col-3; j++) {
    	            if (    table[i][j]== currentChip&& table[i][j+1] == currentChip &&
    	            		table[i][j+2] == currentChip &&
    	            		table[i][j+3] == currentChip) {
    	            	return true;    	           	                	              
    	            } 
    	        }
    	 }      	   
   //Ελεγχος για νικη, καθετα 
    	 for (int i = 0; i < row-3; i++) {	        
 	        for (int j = 0; j < col; j++) {
 	            if (    table[i][j]== currentChip&& table[i+1][j] == currentChip &&
 	            		table[i+2][j] == currentChip &&
 	            		table[i+3][j] == currentChip) {
 	            	return true;  }
 	        }
    	 }
         
         
        //Ελεγχος για νικη, απο πανω προς τα κατω αριστερα
    	 for (int i = 3; i < row; i++) { 
    		    for (int j = 0; j < col - 3; j++) { 
    		        if (table[i][j] == currentChip && 
    		            table[i - 1][j + 1] == currentChip && 
    		            table[i - 2][j + 2] == currentChip && 
    		            table[i - 3][j + 3] == currentChip) {
    		            return true;
    		        }
        	 }
         }
    	//Ελεγχος για νικη, απο πανω προς τα κατω δεξια 
         for (int i = 0; i < row - 3; i++) { 
        	    for (int j = 0; j < col-3; j++) { 
        	        if (table[i][j] == currentChip && 
        	            table[i + 1][j + 1] == currentChip && 
        	            table[i + 2][j + 2] == currentChip && 
        	            table[i + 3][j + 3] == currentChip) {
        	            return true;
        	        }
        		 }
        	 }
		return false;
         }
         
    public boolean isBoardFull() {
    	for(int j=0;j<this.col;j++) {
    		if(table[0][j]=='-')
    			return false;
    	}
    	return true;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
