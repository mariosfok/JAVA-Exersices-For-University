import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("This is Score4");
		
		Scanner scanner = new Scanner(System.in);
		String name1,name2;
		
		//Παίρνουμε τις απαραίτητες πληροφορίες για τους παίκτες.
		 System.out.println("Please enter the name of the 1st player: ");
	        name1 = scanner.nextLine();

	        System.out.println("Please enter the name of the 2nd player: ");
	        name2 = scanner.nextLine();
	        
		Details playerDetails = new Details(name1,name2);
		 
		playerDetails.selectPlayerChips();//Επιλογή του συμβόλου κάθε παίκτη.
		 
		 
	     TableΜaker tablemaker = new TableΜaker(); 
	        tablemaker.createTable(); //Δημιουργια του Ταμπλου.
	        tablemaker.printCurrentTable(); 
	     
	     char[][] gameTable = tablemaker.getTable();//Αναφορα στο ταμπλο ωστε να το περασουμε στην κλαση GameTime και να το ενημερωσουμε.
	        
	     GameTime game = new GameTime(playerDetails, tablemaker, gameTable);
	       game.Gameplay();//Ωρα του παιχνιδιου.
	     
	      
	     scanner.close();		 		
	}
}


	    
	     
		
		

	




