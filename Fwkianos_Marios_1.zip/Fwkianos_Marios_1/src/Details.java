import java.util.Random;
import java.util.Scanner;

public class Details {
    private String name1;
    private String name2;
    private String startingPlayer;
    private char startingPlayerChip;
    private char otherPlayerChip;
    private Scanner obj1;

    public Details(String name1,String name2) {
    	obj1 = new Scanner(System.in);//Αρχικοποιηση του scanner ωστε να ειναι προσβασιμος για ολες τις μεθοδους της κλασης.
    	this.name1 = name1;
    	this.name2 = name2;

    }
    


    public void determineStartingPlayer() {
        Random random = new Random();
        if (random.nextInt(2) == 0) { 
            startingPlayer = name1;
        } else {
            startingPlayer = name2;
        }
    }

    public void selectPlayerChips() {
    	
   
    	determineStartingPlayer();
        
        if (startingPlayer.equals(name1)) {
        	do {
            System.out.print(name1 + ", please select your chip (x/o): ");
            startingPlayerChip  = obj1.next().charAt(0);
            obj1.nextLine();
            if(startingPlayerChip!='o' && startingPlayerChip!='x')
            	System.out.print("Wrong input, ");
            
        	}while(startingPlayerChip!='o' && startingPlayerChip!='x');
            
            otherPlayerChip  = (startingPlayerChip == 'x') ? 'o' : 'x';
            System.out.println(name2 + ", your chip is: " + otherPlayerChip);
        } else {
        	
        	do {
            System.out.print(name2 + ", please select your chip (x/o): ");
            startingPlayerChip = obj1.next().charAt(0);
            obj1.nextLine();
            
            if(startingPlayerChip!='o' && startingPlayerChip!='x')
            	System.out.print("Wrong input, ");
            
        	}while(startingPlayerChip!='o' && startingPlayerChip!='x');
            
            otherPlayerChip = (startingPlayerChip == 'x') ? 'o' : 'x';
            System.out.println(name1 + ", your chip is: " + otherPlayerChip);
        }

        
    }
    
    public char getStartingPlayerChip(){
    	return startingPlayerChip;
    }
 
    public char getOtherPlayerChip() {
    	return otherPlayerChip;
    }

    public String getStartingPlayer() {
        return startingPlayer;
    }

    public String getName1() {
        return name1;
    }

    public String getName2() {
        return name2;
    }

}
