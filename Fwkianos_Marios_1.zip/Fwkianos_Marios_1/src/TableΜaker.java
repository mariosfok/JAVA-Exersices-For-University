
import java.util.Scanner;

class TableΜaker {
    private int row;
    private int col;
    private char[][] table;
    private Scanner obj2;

    public TableΜaker() {
    	obj2 = new Scanner(System.in); //Αρχικοποιηση του scanner ωστε να ειναι προσβασιμος για ολες τις μεθοδους της κλασης.
    }

    public void createTable() {
    	System.out.print("Please enter the number of rows: ");
        do {
            
            this.row = obj2.nextInt();
            if (row < 4 || row > 15) {
                System.out.println("Incorrect input. Please enter the number of rows: ");
            }
        } while (row < 4 || row > 15); 
        System.out.print("Please enter the number of columns: ");
        do {
            
            this.col = obj2.nextInt();
            if (col < 4 || col > 15) {
                System.out.println("Incorrect input. Please enter the number of columns: ");
            }
        } while (col < 4 || col > 15); 
        
        table = new char[this.row][this.col];
        

        
        for(int i = 0; i < row; i++) {
            for(int j = 0; j < col; j++) {
                table[i][j] = '-';
            }
        }
    }
    

    public void printCurrentTable() {
    	System.out.println();
        for (int i = 0; i < row; i++) {
            System.out.print("| "); // left side
            for (int j = 0; j < col; j++) {
                System.out.print(table[i][j] + " ");
            }
            System.out.println("|"); // right side
        }
        
        
        
        for (int j = 0; j < col * 2 + 3; j++) {
            System.out.print("-"); 
        }
        System.out.println(); 
        System.out.print("  ");
        for (int j = 0; j < col; j++) {
        	
            System.out.print((j + 1) + " "); 
        }
        System.out.println();
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }
    public char[][] getTable() {
        return table;
    }

   
}
   

    
    

