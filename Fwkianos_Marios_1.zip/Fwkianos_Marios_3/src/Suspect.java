import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Suspect {

	
	private String name;
	private String codedName;
	private String city;
	
	private ArrayList<String> phoneNumbers;
	private ArrayList<Suspect> possibleAssociates;
	
	private List<Suspect> SuggestedSuspect;
	

	
	public Suspect(String name, String codedName, String city) {
		this.name = name;
		this.codedName = codedName;
		this.city = city;
		this.phoneNumbers = new ArrayList<>();
		this.possibleAssociates = new ArrayList<>();
		
	}
	
	
	
	
	//Νεα προσθήκη,Εργασία 3 
	public List<Suspect> getSuggestedSuspect() {
	    SuggestedSuspect = new LinkedList<>();
	    
	    // Συνεργάτες του Α
	    List<Suspect> ThisPossibleAssociates = this.getPossibleAssociates();
	    
	    // Σύνολο για τους συνεργάτες των συνεργατών του Α
	    Set<Suspect> SuggestedSuspect1 = new HashSet<>();

	    // Πρόσθεσε συνεργάτες των συνεργατών του Α
	    for (Suspect sus : ThisPossibleAssociates) {
	        SuggestedSuspect1.addAll(sus.getPossibleAssociates());
	    }

	    // Αφαίρεσε τους συνεργάτες του Α
	    SuggestedSuspect1.removeAll(ThisPossibleAssociates);

	    // Αφαίρεσε τον ίδιο τον Α 
	    SuggestedSuspect1.remove(this);

	    
	    SuggestedSuspect = new LinkedList<>(SuggestedSuspect1);

	    return SuggestedSuspect;
	}
	
	public void addNumber(String number) {
		phoneNumbers.add(number);
	}

	
	
	public void addAssociate(Suspect associate) {
	       if (!this.possibleAssociates.contains(associate)) {
	           this.possibleAssociates.add(associate);	            
	        } 	
          }
	


	public ArrayList<Suspect> getPossibleAssociates() {
		return possibleAssociates;
	}

	public void setPossibleAssociates(ArrayList<Suspect> possibleAssociates) {
		this.possibleAssociates = possibleAssociates;
	}

	public boolean isConnectedTo(Suspect aSuspect) {
			if (this.possibleAssociates.contains(aSuspect))return true;					
			else return false;
	}
	
	public ArrayList<Suspect> getCommonPartners(Suspect aSuspect) {
	    ArrayList<Suspect> commonPartners = new ArrayList<>();  
	    
	    for (Suspect partner : this.possibleAssociates) {
	      
	        if (aSuspect.possibleAssociates.contains(partner)) {
	            commonPartners.add(partner); 
	        }
	    }
	    
	    return commonPartners;
	}

	public String getName() {
		return name;
	}
	
	public String getCodeName() {
		return codedName;
	}
	
	public ArrayList<String> getPhoneNumbers() {
		return phoneNumbers;
	}
	
	public String getCity() {
		return city;
	}
	
	public static Comparator<Suspect> comparator = new Comparator<Suspect>() {

		@Override
		public int compare(Suspect s1, Suspect s2) {
			return s1.getName().compareTo(s2.getName());
		}
		
	};

	
		
}