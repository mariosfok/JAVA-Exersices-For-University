import java.util.ArrayList;

public class Registry {

	private ArrayList<Suspect> suspects;
	private ArrayList<Communication> coms;
	
	
	public Registry() {
		this.suspects = new ArrayList<>();
		this.coms = new ArrayList<>();
		
	}
	
	public void addSuspect(Suspect aSuspect) {
		suspects.add(aSuspect);
	}
	
	public void addCommunication(Communication aCommunication) {
		coms.add(aCommunication);
		
			    Suspect suspect1 = null; // Ο ύποπτος που έχει το Num1
			    Suspect suspect2 = null; // Ο ύποπτος που έχει το Num2

			    
			    for (Suspect suspect : suspects) {
			        if (suspect1 == null && suspect.getPhoneNumbers().contains(aCommunication.num1)) {
			            suspect1 = suspect; // Εντοπίσαμε τον ύποπτο που έχει τον Num1
			        }
			        if (suspect2 == null && suspect.getPhoneNumbers().contains(aCommunication.num2)) {
			            suspect2 = suspect; // Εντοπίσαμε τον ύποπτο που έχει τον Num2
			        }

			        // Αν έχουμε βρει και τους δύο υπόπτους, σταματάμε την αναζήτηση
			        if (suspect1 != null && suspect2 != null) {
			            break;
			        }
			    }

			    // Αν και οι δύο ύποπτοι βρέθηκαν και είναι διαφορετικοί, ενημερώνουμε τους συνεργάτες
			    if (suspect1 != null && suspect2 != null && suspect1 != suspect2) {  // !=  , Χρησιμοποιείται αφου συγκρίνω αν δείχνουν στην ιδια αναφορα. {
			        suspect1.addAssociate(suspect2);
			        suspect2.addAssociate(suspect1);
			    }
			}
	
	
	public Suspect getSuspectWithMostPartners() {
		int max = -1;
		Suspect maxSuspect = null; 
		for (Suspect suspect : suspects) {
			if(suspect.getPossibleAssociates().size()>max)//Αν το πληθος των επαφων του ύποπτου ειναι μεγαλυτερο απο το max
			{
				max = suspect.getPossibleAssociates().size();
			    maxSuspect = suspect;			
			}	
		}
		return maxSuspect;			
	}	
			
			

	
	
	public PhoneCall getLongestPhoneCallBetween(String number1, String number2) {
			int maxDurationBetween = -1;
			PhoneCall maxPhoneCall=null;
		for (Communication com : coms) {
		    if (com instanceof PhoneCall) { //Αν το αντικειμενο ειναι τυπου PhoneCall και οχι SMS,
		        PhoneCall phoneCall = (PhoneCall) com;
		        if (phoneCall.num1.equals(number1) && phoneCall.num2.equals(number2) ||
		           (phoneCall.num1.equals(number2) && phoneCall.num2.equals(number1))) {
		        	
		        	if(maxDurationBetween<phoneCall.getCallTime())
		        		maxDurationBetween = phoneCall.getCallTime();
		        	    maxPhoneCall = phoneCall;
		        	    
		        }
		    }
		}
		return maxPhoneCall;	
		
	}
	
	public ArrayList<SMS> getMessagesBetween(String number1, String number2) {
	    ArrayList<SMS> filteredMessages = new ArrayList<>(); // Λίστα για να αποθηκευτούν τα μηνύματα που πληρούν τα κριτήρια

	    for (Communication com : coms) {
	        if (com instanceof SMS) {//Αν το αντικειμενο ειναι τυπου SMS και οχι PhoneCall,
	            SMS sms = (SMS) com;
	            
	            if ((sms.num1.equals(number1) && sms.num2.equals(number2)) ||
	                (sms.num1.equals(number2) && sms.num2.equals(number1))) {
	                
	                String messageContent = sms.getMessage(); 
	                if (messageContent.contains("Bomb") || 
	                    messageContent.contains("Attack") || 
                        messageContent.contains("Explosives") || 
                        messageContent.contains("Gun")) {
	                      filteredMessages.add(sms); 
	                }
	              
	            }
	        }
	    }
	    return filteredMessages; 
	}

	
	
}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

