import java.util.ArrayList;
import java.util.List;

public class Fleet {

	private String name;
	private List<Taxi> taxis;
	
	public Fleet(String name) {
		this.name = name;
		this.taxis = new ArrayList<>();
	}
	
	public void storeTaxis(Taxi taxi) {
		taxis.add(taxi);
	}

	public String getName() {
		return name;
	}

	public List<Taxi> getTaxis() {
		return taxis;
	}
	
	public double calculateAutonomia() {
		double sum = 0;
		for(Taxi taxi : taxis) {
			sum += taxi.calculate();
		}
		return sum;
	}
	
}
