
public abstract class Taxi {
	
	protected String numKyk;
	protected String name;
	
	public Taxi(String numKyk, String name) {
		this.numKyk = numKyk;
		this.name = name;
	}

	public String getNumKyk() {
		return numKyk;
	}

	public String getName() {
		return name;
	}
	
	public abstract double calculate();
	
	public abstract String toString();
	

}
