
public class ElectricalTaxi extends Taxi{
	
	private int batteryCount;

	public ElectricalTaxi(String numKyk, String name, int batteryCount) {
		super(numKyk, name);
		this.batteryCount = batteryCount;
	}

	public int getBatteryCount() {
		return batteryCount;
	}

	@Override
	public double calculate() {
		return 70*batteryCount;
	}

	@Override
	public String toString() {
		return "NAI +1";
	}

}
