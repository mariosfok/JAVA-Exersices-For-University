
public abstract class Communication {

	
	protected String num1;
	protected String num2;
	protected int day,month,year;
	
	public Communication(String num1, String num2, int day, int month, int year)
	{
		this.num1 = num1;
		this.num2 = num2; 
	    this.day = day;
	    this.month = month;
	    this.year = year;
	}

	public abstract  void printInfo();
	
	
}
