import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Main {

	public static void main(String[] args) {
		
		//Creation of suspect objects
		Suspect s1 = new Suspect("John Dow", "Sleepy Dog", "Barcelona");
		s1.addNumber("00496955444444");
		s1.addNumber("00496955333333");
		
		Suspect s2 = new Suspect("Danny Rust", "Rusty Knife", "London");
		s2.addNumber("00446999888888");
		
		Suspect s3 = new Suspect("Bob Robson", "Frozen Bear", "Oslo");
		s3.addNumber("00478484777777");
		s3.addNumber("00478484666666");
		s3.addNumber("00478484222222");
		
		Suspect s4 =  new Suspect("Nick Tomson", "Angry Dog", "Berlin");
		s4.addNumber("00493075055555");
		
		//Creation of communication objects
		Communication[] comms = new Communication[15];
		
		comms[0] = new PhoneCall("00496955444444", "00478484777777", 15, 10, 2024, 127);
		comms[1] = new PhoneCall("00496955444444", "00478484777777", 16, 10, 2024, 240);
		comms[2] = new PhoneCall("00446999888888", "00496955333333", 17, 10, 2024, 52);
		comms[3] = new PhoneCall("00446999888888", "00478484777777", 18, 10, 2024, 180);
		comms[4] = new PhoneCall("00478484666666", "00496955333333", 19, 10, 2024, 305);
		comms[5] = new PhoneCall("00496955444444", "00478484222222", 20, 10, 2024, 247);
		comms[6] = new PhoneCall("00478484222222", "00496955333333", 21, 10, 2024, 32);
		
		comms[7] = new SMS("00496955444444", "00478484777777", 10, 10, 2024, "fancy a drink tonight?");
		comms[8] = new SMS("00496955333333", "00446999888888", 11, 10, 2024, "Nitro Bomb prepared");
		comms[9] = new SMS("00446999888888", "00496955444444", 12, 10, 2024, "flying to Berlin tomorrow");
		comms[10] = new SMS("00478484777777", "00446999888888", 13, 10, 2024, "No internet connection today");
		comms[11] = new SMS("00478484777777", "00446999888888", 14, 10, 2024, "Gun Received from Rusty Knife");
		comms[12] = new SMS("00478484777777", "00446999888888", 15, 10, 2024, "Metro Attack ready");
		comms[13] = new SMS("00478484666666", "00446999888888", 16, 10, 2024, "Explosives downtown have been placed");
		comms[14] = new SMS("00493075055555", "00478484222222", 17, 10, 2024, "Call me!");
		
		//Creation of Registry object
		Registry registry = new Registry();
		
		registry.addSuspect(s1);
		registry.addSuspect(s2);
		registry.addSuspect(s3);
		registry.addSuspect(s4);
		
		for(int i=0; i<15; i++)
			registry.addCommunication(comms[i]);
		
		
		//-------------TESTS----------------------
		//Test 1. Suspect With MostPartners
		Suspect topSuspect = registry.getSuspectWithMostPartners();
		System.out.println("Test1: " + topSuspect.getName() + ", " + topSuspect.getCodeName());
		System.out.println();
		
		//Test 2. Longest Phone Call Between
		PhoneCall longestCall = registry.getLongestPhoneCallBetween("00496955444444", "00478484777777");
		System.out.println("Test2: ");
		longestCall.printInfo();
		System.out.println();

		//Test 3. get Suspicious Messages Between
		ArrayList<SMS> listOfMessages = registry.getMessagesBetween("00478484777777", "00446999888888");
		System.out.println("Test3: ");
		for(SMS sms: listOfMessages)
			sms.printInfo();
		System.out.println();
		
		//Test 4. check whether suspects are connected
		System.out.println("Test4: ");
		System.out.println(s1.isConnectedTo(s3));
		System.out.println(s3.isConnectedTo(s2));
		System.out.println();
		
		//Test 5. get List of common partners
		System.out.println("Test5: ");
		ArrayList<Suspect> commonSuspects = s1.getCommonPartners(s3);
		for(Suspect suspect: commonSuspects)
			System.out.println(suspect.getName() + ", " + suspect.getCodeName());
	
	
	
	//Εργασία 3 , Δοκιμη οτι δουλευουν οι συνεργατες.
	
	List<Suspect> suggestedSuspect= s3.getSuggestedSuspect();
	
	System.out.println("--------");
	for(Suspect sus : suggestedSuspect) {
		System.out.println("Suggested suspects for John Dow is: "+ sus.getName());
	}
	
	//Γραφικη διασύνδεση GUI 
	
	//Πρωτο παραθυρο, ευρεση υπόπτου
	JFrame frame = new JFrame("Find Suspect");
	frame.setSize(400,200);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	JTextField nameField = new JTextField(20);
	
    JButton searchButton = new JButton("Search");

	searchButton = new JButton("Search");
	searchButton.addActionListener(new ActionListener() {
		@Override
        public void actionPerformed(ActionEvent e) {
			
            String name = nameField.getText(); 
            Suspect wantedSuspect = registry.getSuspectByName(name);
			
            //Αν υπαρχει ο υποπτος
            if ((wantedSuspect)!=null) {
                JOptionPane.showMessageDialog(frame, "Suspect " + name + " found!");
                
              
    			
    			
    			//(0)
    			JPanel newPanel = new JPanel();
    			newPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
    			newPanel.setBorder(BorderFactory.createLineBorder(Color.black));
               
                
                JFrame newFrame = new JFrame("Suspect Page");
                newFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                newFrame.setSize(1000,1000);
                newFrame.setLayout(new BorderLayout());
                
                
                JTextField suspectName = new JTextField(name);
                JTextField codedName = new JTextField(wantedSuspect.getCodeName());
                JTextArea phoneList = new JTextArea();
                phoneList.setPreferredSize(new Dimension(300, 100));
                
                
                suspectName.setEditable(false);
                codedName.setEditable(false);
                phoneList.setEditable(false);
                
                                    
                ArrayList<String> phoneNumbers = wantedSuspect.getPhoneNumbers();
                
                for (String phoneNumber : phoneNumbers) {
                 phoneList.append(phoneNumber + "\n");
                 }

                newPanel.add(new JLabel("Suspect Name:"));
                newPanel.add(suspectName);
                newPanel.add(new JLabel("Code Name:"));
                newPanel.add(codedName);
                newPanel.add(new JLabel("Phone Numbers:"));
                newPanel.add(new JScrollPane(phoneList));
                
                

              
                
                //(1),(2)
                JPanel smsPanel = new JPanel();
                smsPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); 
                smsPanel.setBorder(BorderFactory.createLineBorder(Color.black));
                
                JTextField phoneNumberField = new JTextField(20);
                
                JTextArea smsArea = new JTextArea();
                smsArea.setPreferredSize(new Dimension(300, 100));
                
                smsArea.setEditable(false);
                
                JButton findSMS = new JButton("Find SMS");
                findSMS.addActionListener(new ActionListener(){
                

					@Override
					public void actionPerformed(ActionEvent e) {
						String phoneNum = phoneNumberField.getText();
						ArrayList<SMS> allMessages = new ArrayList<>();

						for(String phoneNumber : wantedSuspect.getPhoneNumbers()) {
							ArrayList<SMS> messages  = registry.getMessagesBetween(phoneNumber, phoneNum);
							 allMessages.addAll(messages);
						}
						
						for(SMS sms : allMessages) {
							smsArea.append(sms.getMessage()+ "\n");
						}

						
					}
                	
                });
                
                
                smsPanel.add(new JLabel("Phone Number:"));
                smsPanel.add(phoneNumberField);
                smsPanel.add(findSMS);
                smsPanel.add(new JLabel("SMS Found:"));
                smsPanel.add(new JScrollPane(smsArea));
               
                
                //(3)
                JPanel partnersPanel = new JPanel();
                partnersPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); 
                partnersPanel.setBorder(BorderFactory.createLineBorder(Color.black));

                
                JTextArea partnersList = new JTextArea();
                partnersList.setEditable(false);
                partnersList.setPreferredSize(new Dimension(300, 100));
                ArrayList<Suspect> possibleAssociates = wantedSuspect.getPossibleAssociates();
                
                Set<Suspect> possibleAssociatesInOrder = new TreeSet<>(Suspect.comparator);
                possibleAssociatesInOrder.addAll(possibleAssociates);
                
                for (Suspect s : possibleAssociatesInOrder) {
                	partnersList.append(s.getName()+", "+s.getCodeName()+"\n");
                }
                
                
                partnersPanel.add(new JLabel("Partners"));
                
                partnersPanel.add(partnersList);
                
                //(4)
                JPanel suggestedPanel = new JPanel();
                suggestedPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); 
                suggestedPanel.setBorder(BorderFactory.createLineBorder(Color.black));
                
                JTextArea suggestedList = new JTextArea();
                suggestedList.setPreferredSize(new Dimension(300, 100)); 
                List<Suspect> suggestedAssociates = wantedSuspect.getSuggestedSuspect();
                
                Set<Suspect> suggestedAssociatesInOrder = new TreeSet<>(Suspect.comparator);
                suggestedAssociatesInOrder.addAll(suggestedAssociates);
                
                for (Suspect s : suggestedAssociatesInOrder) {
                	suggestedList.append(s.getName()+", "+s.getCodeName()+"\n");
                }

                suggestedList.setEditable(false);
                suggestedPanel.add(new JLabel("Suggested Partners -----> "));
                suggestedPanel.add(new JScrollPane(suggestedList));
                
                
                
                
                //Back to search button
                JButton backButton = new JButton("Back to Search Screen");
                backButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        newFrame.dispose(); 
                        frame.setVisible(true); 
                    }
                });
               

				
                
                
                
                
                
                
              //Οριζω ενα κεντρικο panel
    			JPanel centralPanel = new JPanel();
    			centralPanel.setLayout(new BoxLayout(centralPanel, BoxLayout.Y_AXIS));
    			centralPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    			
                //0
                centralPanel.add(newPanel);
                centralPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                
                //1 , 2
                centralPanel.add(smsPanel);
                centralPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                
                //3
                centralPanel.add(partnersPanel);
                centralPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                
                //4
                centralPanel.add(suggestedPanel);
                
                //Back to search button
                JPanel buttonPanel = new JPanel();
                buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
                buttonPanel.add(backButton, BorderLayout.CENTER);
                centralPanel.add(buttonPanel,BorderLayout.SOUTH);
                
                
                //Main Frame
                newFrame.add(centralPanel, BorderLayout.CENTER);
                newFrame.setVisible(true);

                
 
                
                
                
             
            } else {
                JOptionPane.showMessageDialog(frame, "Suspect " + name + " not found!");
            }
        }
    });
    
	
	
	
	 JPanel panel = new JPanel();
     panel.add(new JLabel("Enter Suspect's Name:"));
     panel.add(nameField);
     panel.add(searchButton);

     // Προσθήκη του panel στο παράθυρο
     frame.add(panel);
	frame.setVisible(true);

	}
	
	

}