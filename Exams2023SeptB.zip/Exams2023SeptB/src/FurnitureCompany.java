import java.util.ArrayList;

public class FurnitureCompany {

	
	ArrayList<Furniture> furns;
	
	public FurnitureCompany(){
		this.furns = new ArrayList<>();
	}
	
	public ArrayList<Furniture> getFurns() {
		return furns;
	}

	public void addFurniture(Furniture furn) {
		furns.add(furn);
		
	}
}
