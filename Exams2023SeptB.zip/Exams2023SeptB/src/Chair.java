
public class Chair extends Furniture{
	

	private String color;
	
	public Chair(String model, int weight, int category, String color) {
		super(model,weight,category);
		this.color = color;
	}

	@Override
	public double calculateCost() {
		if(this.category == 3) {
			return 130;
		}else 
			return 100;
	}

	@Override
	public String toString() {
		
		String categoryTemp = "";
		if(this.category ==1)
			categoryTemp = "Office chair";
		else if (this.category ==2)
			categoryTemp = "Cooperation chair";
		else
			categoryTemp = "Armchair";
		
		
		
		
		return "- Chair info: \n"
			    +model+", "+this.calculateCost()+" Euro"+
				"\nCategory: "+categoryTemp+
				"\nWeight: "+this.weight+
				"\nShelves: "+this.color;
	}
	

}
