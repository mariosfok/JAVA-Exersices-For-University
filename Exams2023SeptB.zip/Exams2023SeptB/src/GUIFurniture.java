import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;




public class GUIFurniture extends JFrame{
	
	private JFrame frame = new JFrame();

	private JPanel panel = new JPanel();
	private JTextField field1 = new JTextField("Enter model");
	private JTextField resultField = new JTextField();
	
	private JTextField field2 = new JTextField("Enter category");

	private JButton searchButton = new JButton("Search Furniture");
	private JButton printButton = new JButton("Print Furniture to Text File");

	private ArrayList<Furniture> furns;
    
    public GUIFurniture(FurnitureCompany comp) {
    	
    	
    	furns =  comp.getFurns();
    	resultField.setPreferredSize(new Dimension(150,150));
    	
    	searchButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				String model = field1.getText();
				
				for(Furniture furn : furns) {
					if(furn.getModel().equals(model)) {
						resultField.setText(furn.toString());
						break;
					}
					
				}
			}
    		
    	});
    	
    	
    	printButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				String selectedCategory = field2.getText();
				
				int selectedCatergory;
				
				if(selectedCategory.equals("Plastic") || selectedCategory.equals("Office chair") ) {
					selectedCatergory = 1;
				}else if (selectedCategory.equals("Metallic") || selectedCategory.equals("Cooperation chair") ) {
					selectedCatergory = 2;
				}else 
					selectedCatergory = 3;
				
				File file = new File("Furnitures.txt");
				
				try {
					FileWriter writer = new FileWriter(file);
					BufferedWriter buffWriter = new BufferedWriter(writer);
					
					for(Furniture furn : furns) {
						if(furn.getCategory() == selectedCatergory) {
							buffWriter.write(furn.toString());
							buffWriter.newLine();
							buffWriter.newLine();
						}
					}
					buffWriter.close();
					writer.close();
					
			
					
					
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			
				
				
				
				
				
			}
    		
    	});
    	
    	
    	
    	
    	
    	
    	
    	panel.add(field1);
    	panel.add(field2);
    	
    	panel.add(searchButton);
    	
    	panel.add(resultField);
    	
    	panel.add(printButton);
    	
    	frame.add(panel);
    	frame.setSize(500,500);
    	frame.setVisible(true);
    	frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    	
    	
    	

     
    
	
  }
    
}
    	
    

    

